package com.example.webymaxhosting;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Webymax webymax = new Webymax();
        EditText date = (EditText) findViewById(R.id.date);
        EditText customerName = (EditText) findViewById(R.id.customerName);
        AutoCompleteTextView countryNames = (AutoCompleteTextView) findViewById(R.id.countries);
        Spinner plans = (Spinner) findViewById(R.id.plans);
        RadioButton growB = (RadioButton) findViewById(R.id.growBig);
        RadioButton growG = (RadioButton) findViewById(R.id.growGreek);
        RadioGroup groupB = (RadioGroup) findViewById(R.id.GrowBig);
        RadioGroup groupG = (RadioGroup) findViewById(R.id.GrowGreek);
        CheckBox unlimited = (CheckBox) findViewById(R.id.unlimited);
        CheckBox stagging = (CheckBox) findViewById(R.id.stagging);
        RadioGroup radioGroup = (RadioGroup) findViewById((R.id.radioGroup2));
        TextView textView = (TextView) findViewById(R.id.textView);

        Button submit = (Button) findViewById(R.id.submit);
        //setting country names to autocompleteviewadapter
        ArrayAdapter<String> adapterCountry = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, webymax.getCountryList());
        countryNames.setAdapter(adapterCountry);


        final DatePickerDialog[] datePickerDialog = new DatePickerDialog[1];
        date.setInputType(InputType.TYPE_NULL);
        //setting datepicker
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                datePickerDialog[0] = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int dayofmonth) {
                        date.setText(dayofmonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                datePickerDialog[0].show();
            }
        });
        //setting plans to spinner adapter
        ArrayAdapter<String> adapterPlans = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, webymax.getPlans());
        adapterPlans.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        plans.setAdapter(adapterPlans);

        //selection of radio group according to growgreek and grow big
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                RadioButton radioButton = (RadioButton) findViewById(id);
                webymax.setRadiotext(radioButton.getText().toString());
                if (id == R.id.growBig) {
                    webymax.setPlancost(36.82);
                    groupB.setVisibility(View.VISIBLE);
                    groupG.setVisibility(View.GONE);
                    groupB.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup radioGroup, int id) {
                            RadioButton radio = (RadioButton) findViewById(id);
                            webymax.setNextRadio(radio.getText().toString());
                            if (radio.getId() == R.id.stagggit) {
                                webymax.setAdditionalCost(5.99);
                            } else {
                                webymax.setAdditionalCost(8.99);
                            }

                        }
                    });

                } else {
                    webymax.setPlancost(47.88);
                    groupG.setVisibility(View.VISIBLE);
                    groupB.setVisibility(View.GONE);
                    groupG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(RadioGroup radioGroup, int i) {
                            RadioButton radio = (RadioButton) findViewById(i);
                            webymax.setNextRadio(radio.getText().toString());
                            if (radio.getId() == R.id.ondemand) {
                                webymax.setAdditionalCost(3.99);
                            } else {
                                webymax.setAdditionalCost(7.99);
                            }
                        }
                    });
                }
            }
        });
        //gettign  country values from adapter view
        countryNames.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                webymax.setCountry((String) adapterView.getItemAtPosition(i));


            }
        });

        //getting checkboxes information
        unlimited.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    webymax.setCheckText(compoundButton.getText().toString());
                    webymax.setUnlimCost(9.25);

                } else {
                    webymax.setUnlimCost(0.0);
                    webymax.setCheckText(null);
                }
            }
        });
        stagging.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    webymax.setCheckText(compoundButton.getText().toString());
                    webymax.setStagCost(7.49);
                } else {
                    webymax.setCheckText(null);
                    webymax.setStagCost(0);
                }

            }
        });

        //getting plan and setting cost according to plan
        plans.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                webymax.setWebspace(adapterView.getItemAtPosition(i).toString());
                if (webymax.getWebspace() == "10GB") {
                    webymax.setWebspaceCost(3.99);
                } else if (webymax.getWebspace() == "20GB") {
                    webymax.setWebspaceCost(6.99);
                } else if (webymax.getWebspace() == "40GB") {
                    webymax.setWebspaceCost(12.99);
                } else {
                    webymax.setWebspaceCost(0);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //getting locale and currency symbol
        Currency currency = Currency.getInstance(Locale.getDefault());
        String symbol = currency.getSymbol();
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        //submitting and showing in textview
        //Note: I haven't used toast here because I am not able to put long string in toast
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (unlimited.isChecked() && stagging.isChecked()) {
                    webymax.setCheckText("Unlimited and Staging");
                }
                webymax.setCostBeforeTax(webymax.getPlancost() + webymax.getUnlimCost() +
                        webymax.getStagCost() + webymax.getWebspaceCost() + webymax.getAdditionalCost());
                webymax.setFinalCost(webymax.getCostBeforeTax() + webymax.getCostBeforeTax() * 0.13);

                textView.setText("On " + date.getText()
                        + " for " + customerName.getText() + " from " + webymax.getCountry() + " plan " + webymax.getRadiotext() +
                        " with " + webymax.getCheckText() + " websites, " + webymax.getWebspace() + " webspace and " + webymax.getNextRadio() + " cost " + symbol + decimalFormat.format(webymax.getFinalCost()));
            }
        });
    }

}