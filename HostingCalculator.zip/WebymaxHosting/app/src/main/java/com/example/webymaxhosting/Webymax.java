package com.example.webymaxhosting;

public class Webymax {
    private String[] countryList;
    private String[] Plans;
    private String country, radiotext, checkText, webspace, nextRadio;
    private double plancost, unlimCost, stagCost, webspaceCost, additionalCost, costBeforeTax, finalCost;


    //construction for intialization
    public Webymax() {
        countryList = new String[]{"India", "Canada", "USA", "Africa", "Australia", "New Zealand", "Pakistan"};
        Plans = new String[]{"Select Plan", "10GB", "20GB", "40GB"};

    }

    //getter and setter methods
    public String[] getCountryList() { return countryList; }

    public void setCountryList(String[] countryList) {
        this.countryList = countryList;
    }

    public String[] getPlans() {
        return Plans;
    }

    public void setPlans(String[] plans) {
        Plans = plans;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getRadiotext() {
        return radiotext;
    }

    public void setRadiotext(String radiotext) {
        this.radiotext = radiotext;
    }

    public String getCheckText() {
        return checkText;
    }

    public void setCheckText(String checkText) {
        this.checkText = checkText;
    }

    public String getWebspace() {
        return webspace;
    }

    public void setWebspace(String webspace) {
        this.webspace = webspace;
    }

    public String getNextRadio() {
        return nextRadio;
    }

    public void setNextRadio(String nextRadio) {
        this.nextRadio = nextRadio;
    }

    public double getPlancost() {
        return plancost;
    }

    public void setPlancost(double plancost) {
        this.plancost = plancost;
    }

    public double getUnlimCost() {
        return unlimCost;
    }

    public void setUnlimCost(double unlimCost) {
        this.unlimCost = unlimCost;
    }

    public double getStagCost() {
        return stagCost;
    }

    public void setStagCost(double stagCost) {
        this.stagCost = stagCost;
    }

    public double getWebspaceCost() {
        return webspaceCost;
    }

    public void setWebspaceCost(double webspaceCost) {
        this.webspaceCost = webspaceCost;
    }

    public double getAdditionalCost() {
        return additionalCost;
    }

    public void setAdditionalCost(double additionalCost) {
        this.additionalCost = additionalCost;
    }

    public double getCostBeforeTax() {
        return costBeforeTax;
    }

    public void setCostBeforeTax(double costBeforeTax) {
        this.costBeforeTax = costBeforeTax;
    }

    public double getFinalCost() {
        return finalCost;
    }

    public void setFinalCost(double finalCost) {
        this.finalCost = finalCost;
    }


}
