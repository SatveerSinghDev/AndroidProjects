package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

//This class is used to show the list of activities
public class ActivitiesListActivity extends AppCompatActivity {

    private TextView welcomeText;
    ArrayList<ActivityDetails> activityDetails;
    ArrayList<UserAct> favdDetails;
    ListView listView;
    Button logout, favList, receipt;
    public UserDetails userData;
    private SharedPreferences prefs;
    private static final String SP_NAME = "MY_SP";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activities_list);

        //getting singleton instance ActivitesDB file
        userData = ActivitiesDB.getInstance().getUser();
        favdDetails = ActivitiesDB.getInstance().getFavouriteList();
        activityDetails = ActivitiesDB.getInstance().getActivityList();
        UserDetails user = (UserDetails) ActivitiesDB.getInstance().getUser();

        String name = " ";
        welcomeText = (TextView) findViewById(R.id.welcome);
        logout = (Button) findViewById(R.id.Logout);
        receipt = (Button) findViewById(R.id.receipt);
        favList = (Button) findViewById(R.id.favouriteList);

        ArrayList<String> activityName = new ArrayList<>();
        ArrayList<Float> price = new ArrayList<>();
        ArrayList<Integer> imageName = new ArrayList<>();
        //getting login data from Activity db
        this.prefs = this.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);

        if (user.getName() == null) {
            user.setName(prefs.getString("userName", ""));
            user.setId(prefs.getInt("userId", 0));
        }
        name = user.getName();

        welcomeText.setText("Welcome " + name + "!");
        SharedPreferences.Editor prefEditor = this.prefs.edit();
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prefEditor.clear();
                prefEditor.commit();
                Intent i = new Intent(ActivitiesListActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
        //setting activity details
        for (int i = 0; i < activityDetails.size(); i++) {
            activityName.add(activityDetails.get(i).getNameOfActivity());
            price.add(activityDetails.get(i).getPrice());
            imageName.add(activityDetails.get(i).getImageName());
        }
        //showing activity via adapter
        MyListAdapter adapter = new MyListAdapter(this, activityName, imageName, price);
        listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //sending data to MoreActivityDetails screen via intent
                Intent i2 = new Intent(ActivitiesListActivity.this, MoreActivityDetails.class);
                i2.putExtra("activity_data", (Serializable) activityDetails.get(i));
                i2.putExtra("User_data", (Serializable) user);
                i2.putExtra("Add_favourite", "Add to Favourite");
                String x = Integer.toString(i);
                i2.putExtra("Index", x);
                startActivity(i2);
            }
        });
        //sending data to favourite Activity
        favList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent favv = new Intent(ActivitiesListActivity.this, FavAct.class);
                favv.putExtra("User_data", (Serializable) user);
                startActivity(favv);
            }
        });
        //sending data to Previous Booking
        receipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(ActivitiesListActivity.this, PreviousBookings.class);
                j.putExtra("User_data", user);
                startActivity(j);
            }
        });
    }


    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }
}