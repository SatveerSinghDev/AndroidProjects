package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

//this is used for showing Booking Receipt
public class BookingReceipt extends AppCompatActivity {

    TextView receiptActivityName, receiptUserName, receiptCompanyName, receiptPrice, ticketHeading;
    Button homePage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_receipt);

        Intent currentIntent = this.getIntent();

        ticketHeading = (TextView) findViewById(R.id.heading);
        receiptActivityName = (TextView) findViewById(R.id.receiptActivityName);
        receiptUserName = (TextView) findViewById(R.id.receiptUserName);
        receiptCompanyName = (TextView) findViewById(R.id.receiptCompanyName);
        receiptPrice = (TextView) findViewById(R.id.receiptPrice);
        homePage = (Button) findViewById(R.id.homePage);

        //User details get the user data for booking
        UserDetails userDetails = (UserDetails) currentIntent.getSerializableExtra("User_data");
        //Activity details get the booked activity
        ActivityDetails activityDetails = (ActivityDetails) currentIntent.getSerializableExtra("activity_data");
        String num = (String) currentIntent.getStringExtra("ticket_number");
        if (num == null) {
            num = "";
        }
        //setting data for the receipt
        receiptPrice.setText("$" + activityDetails.getPrice());
        receiptActivityName.setText(activityDetails.getNameOfActivity());
        receiptCompanyName.setText(activityDetails.getCompanyName());
        receiptUserName.setText(userDetails.getName());
        ticketHeading.setText("RECEIPT " + num);

        //opening the main activity by clicking
        homePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(BookingReceipt.this, ActivitiesListActivity.class);
                i.putExtra("User_data", userDetails);
                i.putExtra("activity_data", activityDetails);
                startActivity(i);
                finish();
            }
        });

    }
}