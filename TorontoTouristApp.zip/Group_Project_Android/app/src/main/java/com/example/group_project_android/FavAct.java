package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;

//this class is used for showing favourite list of activity showing the favourite options of the user
public class FavAct extends AppCompatActivity {
    ArrayList<UserAct> favouriteDetails;
    ListView listViewFavourite;
    ArrayList<ActivityDetails> activityDetails;
    Button removeAll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);

        ArrayList<String> activityName = new ArrayList<>();
        ArrayList<Float> price = new ArrayList<>();
        ArrayList<Integer> imageName = new ArrayList<>();
        removeAll = (Button) findViewById(R.id.removeAll);
        Intent currentIntent = this.getIntent();
        //getting user details from the activity
        UserDetails userDetails = (UserDetails) currentIntent.getSerializableExtra("User_data");
        favouriteDetails = ActivitiesDB.getInstance().getFavouriteList();
        activityDetails = ActivitiesDB.getInstance().getActivityList();

        //getting the favourite list of details
        for (int i = 0; i < favouriteDetails.size(); i++) {
            if (favouriteDetails.get(i).userDetails.getId() == userDetails.getId()) {
                activityName.add(favouriteDetails.get(i).activityDetails.getNameOfActivity());
                price.add(favouriteDetails.get(i).activityDetails.getPrice());
                imageName.add(favouriteDetails.get(i).activityDetails.getImageName());
            }
        }
        //showing favourite list via adapter
        MyListAdapter adapter = new MyListAdapter(this, activityName, imageName, price);
        listViewFavourite = (ListView) findViewById(R.id.list);
        listViewFavourite.setAdapter(adapter);
        //removing activities from the favourite
        removeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < favouriteDetails.size(); i++) {
                    if (favouriteDetails.get(i).userDetails.getId() == userDetails.getId()) {
                        favouriteDetails.remove(i);
                        i = -1;
                    }
                }
                Toast.makeText(getApplicationContext(), "All favourites removed!", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(FavAct.this, ActivitiesListActivity.class);
                i.putExtra("User_data", userDetails);
                startActivity(i);
                finish();
            }
        });
        //favourite list clickable showing details
        listViewFavourite.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent i2 = new Intent(FavAct.this, MoreActivityDetails.class);
                i2.putExtra("activity_data", (Serializable) activityDetails.get(i));
                i2.putExtra("User_data", (Serializable) userDetails);
                i2.putExtra("A", "Remove from Favourite");
                String x = Integer.toString(i);
                i2.putExtra("I", x);
                startActivity(i2);

            }
        });
        listViewFavourite.invalidateViews();

    }
}