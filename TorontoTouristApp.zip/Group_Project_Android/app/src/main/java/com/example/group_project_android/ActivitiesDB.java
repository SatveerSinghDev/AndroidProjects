package com.example.group_project_android;

import java.util.ArrayList;

//This is singleton class to store all the necessary data
public class ActivitiesDB {
    //this is singleton instance for gettign activity and user details in every class
    private static ActivitiesDB instance = null;

    public static ActivitiesDB getInstance() {
        if (instance == null) {
            instance = new ActivitiesDB();
        }
        return instance;
    }

    //constructor for setting data
    public ActivitiesDB() {
        this.activityList = new ArrayList<ActivityDetails>();
        //setting activity details
        activityList.add(new ActivityDetails(1, "AMUSEMENT PARK", "With more than 30 rides and attractions and 14 mouth-watering food outlets, Centre Island’s iconic Centreville Amusement Park is the ultimate summer destination for families with young children!", 4, "Alpha Tours", 50, R.drawable.amp, 14844458));
        activityList.add(new ActivityDetails(2, "MUSEUM", "explore the history, art and culture of Toronto at The Museum of Contemporary Art.", 3, "Beta Tours", 10, R.drawable.mueseum, 12212448));
        activityList.add(new ActivityDetails(3, "BEACH", "Also known as “The Beaches,” this relaxed neighbourhood with a small-town vibe is a top summer destination, drawing families and tourists to its sandy beaches and quaint boardwalk. ", 5, "Gamma Tours", 5, R.drawable.beach, 12211445));
        activityList.add(new ActivityDetails(4, "ICE SKATING", "The sound of blades gliding on ice, the crisp winter air and a mug of steaming hot chocolate warming your hands.", 5, "Theta Tours", 40, R.drawable.iceskate, 12211445));
        activityList.add(new ActivityDetails(5, "NATURE WALK", "Looking for a great trail near Toronto, Ontario? BELTLINE TRAIL has THE great trail running trails, hiking trails, mountain biking trails and more, with hand-curated trail maps and driving directions as well as detailed reviews and photos from hikers, campers, and nature lovers like you.", 2, "Greek Tours", 5, R.drawable.natue, 12211445));

    }

    private ArrayList<ActivityDetails> activityList;
    //this favlist include Activity and User details
    private ArrayList<UserAct> favouriteList = new ArrayList<>();
    //this booklist include all the list of booking
    private ArrayList<UserAct> bookingList = new ArrayList<>();
    private UserDetails user = new UserDetails();

    //return User Activity
    public ArrayList<UserAct> getFavouriteList() {
        return favouriteList;
    }

    public ArrayList<UserAct> getBookingList() {
        return bookingList;
    }

    public ArrayList<ActivityDetails> getActivityList() {
        return this.activityList;
    }

    public UserDetails getUser() {
        return user;
    }
}
