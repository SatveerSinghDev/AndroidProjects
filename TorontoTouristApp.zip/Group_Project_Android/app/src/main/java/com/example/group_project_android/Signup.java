package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//this class is used for signup
public class Signup extends AppCompatActivity {

    EditText username, emailSignUp, password, confirmPassword;
    Button signup, signin;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        username = (EditText) findViewById(R.id.UserName);
        emailSignUp = (EditText) findViewById(R.id.EmailSingup);
        password = (EditText) findViewById(R.id.Password);
        confirmPassword = (EditText) findViewById(R.id.confirmPassword);

        signup = (Button) findViewById(R.id.singup);
        signin = (Button) findViewById(R.id.signIN);
        dbHelper = new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String email = emailSignUp.getText().toString();
                String pass = password.getText().toString();
                String conPass = confirmPassword.getText().toString();
                //checking fields for validation
                if (user.equals("") || pass.equals("") || conPass.equals("") || email.equals("")) {
                    Toast.makeText(Signup.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equals(conPass)) {
                        //checking user exist or not
                        Boolean checkuser = dbHelper.checkusername(email);
                        if (checkuser == false) {
                            //if not exist then insert data
                            Boolean insert = dbHelper.insertData(user, email, pass);
                            if (insert == true) {
                                Toast.makeText(Signup.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Signup.this, "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Signup.this, "User Already Exist", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Signup.this, "Password Doesn't match", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}