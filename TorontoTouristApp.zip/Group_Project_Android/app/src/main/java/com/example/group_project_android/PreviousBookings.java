package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.io.Serializable;
import java.util.ArrayList;

//this class is showing the list of previously booked tickets
public class PreviousBookings extends AppCompatActivity {
    ArrayList<UserAct> bokingList;
    ListView listViewBooking;
    ArrayList<ActivityDetails> activityDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previous_bookings);

        ArrayList<String> activityName = new ArrayList<>();
        ArrayList<Float> price = new ArrayList<>();
        ArrayList<Integer> imageName = new ArrayList<>();

        Intent currentIntent = this.getIntent();
        UserDetails userDetails = (UserDetails) currentIntent.getSerializableExtra("User_data");
        bokingList = ActivitiesDB.getInstance().getBookingList();
        activityDetails = ActivitiesDB.getInstance().getActivityList();
        //getting booking list
        for (int i = 0; i < bokingList.size(); i++) {
            if (bokingList.get(i).userDetails.getId() == userDetails.getId()) {
                activityName.add(bokingList.get(i).activityDetails.getNameOfActivity());
                price.add(bokingList.get(i).activityDetails.getPrice());
                imageName.add(bokingList.get(i).activityDetails.getImageName());
            }
        }
        //showing booking list
        MyListAdapter adapter = new MyListAdapter(this, activityName, imageName, price);
        listViewBooking = (ListView) findViewById(R.id.previousList);
        listViewBooking.setAdapter(adapter);
        listViewBooking.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent i2 = new Intent(PreviousBookings.this, BookingReceipt.class);
                i2.putExtra("activity_data", (Serializable) activityDetails.get(i));
                i2.putExtra("User_data", (Serializable) userDetails);
                String x = Integer.toString(++i);
                i2.putExtra("ticket_number", "# " + x);

                startActivity(i2);

            }
        });
        listViewBooking.invalidateViews();
    }
}