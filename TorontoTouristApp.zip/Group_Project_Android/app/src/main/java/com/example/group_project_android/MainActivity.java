package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

//this is main activity for login user
public class MainActivity extends AppCompatActivity {

    private TextInputEditText mEmail, mPassword;
    private Button mLogin, mSignup;
    DBHelper dbHelper;
    private SharedPreferences prefs;
    private CheckBox rememberMe;
    private static final String SP_NAME = "MY_SP";
    public UserDetails userData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mEmail = (TextInputEditText) findViewById(R.id.email);
        mPassword = (TextInputEditText) findViewById(R.id.password);
        mLogin = (Button) findViewById(R.id.login);
        rememberMe = (CheckBox) findViewById(R.id.rememberMe);
        mSignup = (Button) findViewById(R.id.Signup);
        dbHelper = new DBHelper(this);
        userData = ActivitiesDB.getInstance().getUser();
        this.prefs = this.getSharedPreferences(SP_NAME, Context.MODE_PRIVATE);

        //directily opening activity of login user if they check remember button
        if (this.prefs.contains("userName")) {
            Intent i1 = new Intent(MainActivity.this, ActivitiesListActivity.class);
            startActivity(i1);
        }

        SharedPreferences.Editor prefEditor = this.prefs.edit();
        mSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Signup.class);
                startActivity(intent);
            }
        });
        //login click listener
        mLogin.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View view) {
                String userEmail = mEmail.getText().toString();
                String pass = mPassword.getText().toString();
                //chekcing userEmail and pass for not null
                if (userEmail.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Please enter all details", Toast.LENGTH_SHORT).show();
                } else {
                    //checking email and password in database via DBhelper
                    Boolean checkuserpass = dbHelper.checkusernamePassword(userEmail, pass);
                    if (checkuserpass == true) {
                        Cursor cursor = dbHelper.viewData(userEmail, pass);

                        if (cursor != null && cursor.getCount() > 0) {
                            if (cursor.moveToFirst()) {
                                do {
                                    userData.setId(cursor.getInt(cursor.getColumnIndex("id")));
                                    userData.setName(cursor.getString(cursor.getColumnIndex("username")));
                                } while (cursor.moveToNext());
                            }
                        }
                        if (rememberMe.isChecked()) {
                            //if user check remember me function
                            prefEditor.putString("userName", userData.getName());
                            prefEditor.putInt("userId", userData.getId());
                            prefEditor.apply();
                            Intent intent = new Intent(MainActivity.this, ActivitiesListActivity.class);
                            intent.putExtra("User_data", userData);
                            startActivity(intent);


                        } else {

                            Intent intent = new Intent(MainActivity.this, ActivitiesListActivity.class);
                            prefEditor.putInt("userId", userData.getId());
                            prefEditor.apply();
                            intent.putExtra("User_data", userData);
                            startActivity(intent);
                        }
                        Toast.makeText(MainActivity.this, "Sign In successfull", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), ActivitiesListActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}