package com.example.group_project_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

//This class showing all the activity detials
public class MoreActivityDetails extends AppCompatActivity {

    TextView activityName, description, price, companyName;
    Button favButton, share, book;
    ArrayList<UserAct> favDetails, booklist;
    ImageView phoneIcon, image;
    RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_details);
        //getting single ton instance
        favDetails = ActivitiesDB.getInstance().getFavouriteList();
        booklist = ActivitiesDB.getInstance().getBookingList();

        phoneIcon = (ImageView) findViewById(R.id.phoneicon);
        activityName = (TextView) findViewById(R.id.activityName);
        description = (TextView) findViewById(R.id.description);
        price = (TextView) findViewById(R.id.price);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        book = (Button) findViewById(R.id.book);
        companyName = (TextView) findViewById(R.id.companyName);
        favButton = (Button) findViewById(R.id.favourites);
        share = (Button) findViewById(R.id.share);
        image = (ImageView) findViewById(R.id.imageView1);

        Intent currentIntent = this.getIntent();
        ActivityDetails activityDetails = (ActivityDetails) currentIntent.getSerializableExtra("activity_data");
        UserDetails userDetails = (UserDetails) currentIntent.getSerializableExtra("User_data");
        String x = currentIntent.getStringExtra("Add_favourite");
        String index = currentIntent.getStringExtra("Index");

        favButton.setText(x);

        if (activityDetails != null) {
            //setting data
            activityName.setText(activityDetails.getNameOfActivity());
            price.setText("$" + activityDetails.getPrice());
            description.setText(activityDetails.getDescription());
            companyName.setText(activityDetails.getCompanyName());
            ratingBar.setRating(activityDetails.getStarRating());
            image.setImageResource(activityDetails.getImageName());
            ;
        }

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //for sharing activity with other app
                Intent myIntent = new Intent(Intent.ACTION_SEND);
                myIntent.setType("text/plain");
                String body = activityDetails.getNameOfActivity() + "\n" + activityDetails.getCompanyName() + "\n " + "$" + activityDetails.getPrice();
                String sub = activityDetails.getNameOfActivity();
                myIntent.putExtra(Intent.EXTRA_SUBJECT, sub);
                myIntent.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(myIntent, "Share via"));
            }
        });
        phoneIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri u = Uri.parse("tel:" + activityDetails.num);

                // Create the intent and set the data for the
                // intent as the phone number.
                Intent i = new Intent(Intent.ACTION_DIAL, u);

                try {
                    // Launch the Phone app's dialer with a phone
                    // number to dial a call.
                    startActivity(i);
                } catch (SecurityException s) {
                    // show() method display the toast with
                    // exception message.
                    Toast.makeText(MoreActivityDetails.this, "Error Occurred", Toast.LENGTH_SHORT).show();
                }
            }

        });
        favButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //remove the activity from favourite list
                if (favButton.getText().equals("Remove from Favourite")) {
                    favDetails.remove(Integer.parseInt(index));
                    Toast.makeText(getApplicationContext(), "Removed from favourite", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MoreActivityDetails.this, ActivitiesListActivity.class);
                    i.putExtra("User_data", userDetails);
                    startActivity(i);
                } else {
                    boolean check = false;
                    for (int i = 0; i < favDetails.size(); i++) {

                        if ((favDetails.get(i).activityDetails.id == activityDetails.id) && (favDetails.get(i).userDetails.getId() == userDetails.getId())) {
                            check = true;
                        }
                    }
                    if (check == false) {
                        favDetails.add(new UserAct(userDetails, activityDetails));
                        Toast.makeText(MoreActivityDetails.this, "Added to favourites!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MoreActivityDetails.this, "Already in Favourites!", Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });
        //this button is used for bookinh
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                booklist.add(new UserAct(userDetails, activityDetails));

                Intent i = new Intent(MoreActivityDetails.this, BookingReceipt.class);
                i.putExtra("User_data", userDetails);
                i.putExtra("activity_data", activityDetails);
                startActivity(i);
                finish();
            }
        });
    }

}