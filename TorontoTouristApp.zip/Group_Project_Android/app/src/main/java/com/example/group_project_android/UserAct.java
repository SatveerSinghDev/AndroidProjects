package com.example.group_project_android;

import java.io.Serializable;

//this class is used to link activity to a user
public class UserAct implements Serializable {
    UserDetails userDetails;
    ActivityDetails activityDetails;

    public UserAct(UserDetails us, ActivityDetails act) {
        this.userDetails = us;
        this.activityDetails = act;
    }

}

