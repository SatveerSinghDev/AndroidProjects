package com.example.group_project_android;

import java.io.Serializable;

//this is the user model class for collecting user details
public class UserDetails implements Serializable {
    String Name;
    int id;

    public UserDetails() {

    }

    public UserDetails(String name, int id) {
        this.Name = name;
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
