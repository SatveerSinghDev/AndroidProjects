    package com.example.group_project_android;

    import java.io.Serializable;
    //Detials of Activity
    public class ActivityDetails implements  Serializable {
        String nameOfActivity;
        String description;
        float starRating;
        String companyName;
        float price;
        int imageName;
        int id;
        long num;



        //intialize data via constructor
        public ActivityDetails(int id,String nameOfActivity, String description, float starRating, String companyName, float price,int imageName,long num) {
            this.id = id;
            this.nameOfActivity = nameOfActivity;
            this.description = description;
            this.starRating = starRating;
            this.companyName = companyName;
            this.price = price;
            this.imageName = imageName;
            this.num=num;

        }


    //getter and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getNameOfActivity() {
            return nameOfActivity;
        }

        public void setNameOfActivity(String nameOfActivity) {
            this.nameOfActivity = nameOfActivity;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public float getStarRating() {
            return starRating;
        }

        public void setStarRating(float starRating) {
            this.starRating = starRating;
        }

        public String getCompanyName() {
            return companyName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public float getPrice() {
            return price;
        }

        public void setPrice(float price) {
            this.price = price;
        }

        public int getImageName() {
            return imageName;
        }

        public long getNum() {
            return num;
        }

        public void setNum(long num) {
            this.num = num;
        }

        public void setImageName(int imageName) {
            this.imageName = imageName;
        }

    }
