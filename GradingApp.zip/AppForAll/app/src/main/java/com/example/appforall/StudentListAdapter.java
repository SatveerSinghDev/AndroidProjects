package com.example.appforall;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Student> mList;
//this class is used for how values showing in User Interface
    public StudentListAdapter(List<Student> list, Context context){
        super();
        mList = list;
    }
    class  ViewHolder extends RecyclerView.ViewHolder{
        public TextView mId;
        public TextView mFirstName;
        public TextView mLastName;
        public TextView mMarks;
        public TextView mProgrameName;
        public TextView mCredit;


        public ViewHolder(View itemView) {
            super(itemView);
            mId = (TextView) itemView.findViewById(R.id.txtId);
            mFirstName = (TextView) itemView.findViewById(R.id.fname);
            mLastName = (TextView) itemView.findViewById(R.id.lname);
            mMarks = (TextView) itemView.findViewById(R.id.marks);
            mProgrameName = (TextView) itemView.findViewById(R.id.programeName);
            mCredit = (TextView) itemView.findViewById(R.id.credit);
        }

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view  = LayoutInflater.from(parent.getContext()).inflate(R.layout.record_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return  viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewholder, int position) {
    Student student = mList.get(position);
        //setting values to  the User Interface
        ((ViewHolder) viewholder).mId.setText(Integer.toString(student.getId()));
        ((ViewHolder) viewholder).mFirstName.setText(student.getFirstName());
        ((ViewHolder) viewholder).mLastName.setText(student.getLastName());
        ((ViewHolder) viewholder).mMarks.setText(student.getMarks());
        ((ViewHolder) viewholder).mCredit.setText(Integer.toString(student.getCredit()));
        ((ViewHolder) viewholder).mProgrameName.setText(student.getProgrammeName());

    }

    @Override
    public int getItemCount() {
        return mList.size();
    }
}
