package com.example.appforall;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GradeEntry#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GradeEntry extends Fragment {
DataBaseHelper dataBaseHelper;
    boolean insert;
    RadioButton radioButton;
    int cred;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public GradeEntry() {
        // Required empty public constructor

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GradeEntry.
     */
    // TODO: Rename and change types and number of parameters
    public static GradeEntry newInstance(String param1, String param2) {
        GradeEntry fragment = new GradeEntry();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view;

        view = inflater.inflate(R.layout.fragment_grade_entry, container, false);
        EditText firstName = (EditText) view.findViewById(R.id.first_name);
        EditText lastName = (EditText) view.findViewById(R.id.last_name);
        EditText marks = (EditText) view.findViewById(R.id.marks);
        Spinner course_spinner = (Spinner) view.findViewById(R.id.spinner);
        RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.radioGroup);
        Button submit = (Button) view.findViewById(R.id.submit);
        String[] course = new String[]{"Select Course", "PROG8480", "PROG8470", "PROG8460", "PROG8450"};
        ArrayAdapter<String> adapterCourse = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_dropdown_item, course);
        adapterCourse.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        course_spinner.setAdapter(adapterCourse);
        dataBaseHelper = new DataBaseHelper(getActivity());

    //this is used for selecting radio button
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.one:
                        cred = 1;
                        break;
                    case R.id.two:
                        cred = 2;
                        break;
                    case R.id.three:
                        cred = 3;
                        break;
                    case R.id.four:
                        cred = 4;
                        break;
                }
            }
        });

        //this is for submitting data in database.
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get the values from Student class
                Student student = new Student(firstName.getText().toString(),lastName.getText().toString(),marks.getText().toString(),course_spinner.getSelectedItem().toString(),cred);
                //inserting in the database
                insert = dataBaseHelper.InsertStudent(student);
                if(insert){
                    Toast.makeText(getActivity(),"Record Added",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getActivity(),"Record not Added",Toast.LENGTH_SHORT).show();
                }

            }
        });
        return view;
    }
}