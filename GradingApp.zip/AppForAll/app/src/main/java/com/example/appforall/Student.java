package com.example.appforall;
//this class is used for getting and setting the data values
public class Student {
    private String firstName;
    private String lastName;
    private String marks;
    private String programmeName;
    private int credit;
    private int id;

    public Student(){

    }
    public Student(String firstName,String lastName, String marks, String programmeName, int credit){
        this.firstName = firstName;
        this.lastName = lastName;
        this.marks = marks;
        this.programmeName = programmeName;
        this.credit = credit;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getProgrammeName() {
        return programmeName;
    }

    public void setProgrammeName(String programmeName) {
        this.programmeName = programmeName;
    }



    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarks() {
        return marks;
    }

    public void setMarks(String marks) {
        this.marks = marks;
    }
}
