package com.example.appforall;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static  final String dbname = "College.db";
    public static  final int version =1;
    public static  final String TABLE_NAME = "Student";
    public static  final String COL1 = "Id";
    public static  final String COL2 = "FirstName";
    public static  final String COL3 = "LastName";
    public static  final String COL4 = "Marks";
    public static  final String COL5 = "Credit";
    public static  final String COL6 = "ProgrameName";
    private static  final String CREATE_TABLE = "CREATE TABLE " +TABLE_NAME+"( "+COL1 +" INTEGER PRIMARY KEY AUTOINCREMENT, "+COL2+" TEXT NOT NULL, "+ COL3+" TEXT NOT NULL, "+COL4+ " TEXT NOT NULL, "+COL5+" INTEGER NOT NULL, "+COL6+" TEXT NOT NULL );";

    public static  final String DROP_TABLE = "DROP TABLE IF EXISTS "+TABLE_NAME;

    public DataBaseHelper(@Nullable Context context){
        //this is used for connection
        super(context,dbname,null,version);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //this is used for creating table in database
        sqLiteDatabase.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //this is used for drop table
        sqLiteDatabase.execSQL(DROP_TABLE);
        onCreate(sqLiteDatabase);

    }
    public  boolean InsertStudent(Student student){
        //this is used for storing values in database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL2,student.getFirstName());
        contentValues.put(COL3,student.getLastName());
        contentValues.put(COL4,student.getMarks());
        contentValues.put(COL5,student.getCredit());
        contentValues.put(COL6,student.getProgrammeName());

         long result = db.insert(TABLE_NAME,null,contentValues);
        if(result == -1){
            return false;
        }
        else{
            return true;
        }

    }
    public Cursor viewData(){
        //this is used for viewing data
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("Select * from "+ TABLE_NAME,null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor viewDatabyId(String id){
        //this is used for getting data by id
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("Select * from "+ TABLE_NAME+ " WHERE "+COL1+" = "+id,null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public Cursor viewDatabyPC(String pc){
        //this is used for getting data by program code.
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("Select * from "+ TABLE_NAME+" WHERE "+COL6+" = '"+pc+"'",null);
        if(cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
}
