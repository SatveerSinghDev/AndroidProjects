package com.example.appforall;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Search#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Search extends Fragment {
    String PC,ID;
    boolean flag = true;
    String[] course = new String[]{"Select Course", "PROG8480", "PROG8470", "PROG8460", "PROG8450"};
    private List<Student> mList = new ArrayList<>();
    DataBaseHelper dataBaseHelper;
    Cursor cursor;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Search() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Search.
     */
    // TODO: Rename and change types and number of parameters
    public static Search newInstance(String param1, String param2) {
        Search fragment = new Search();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("Range")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        dataBaseHelper = new DataBaseHelper(getActivity());
        View view = inflater.inflate(R.layout.fragment_search, container, false);

        RadioGroup radioGroup = (RadioGroup) view.findViewById(R.id.radioGroup2);
        Spinner course_spinner = (Spinner) view.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapterCourse = new ArrayAdapter<String>(getContext(), android.R.layout.simple_spinner_dropdown_item, course);
        adapterCourse.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        course_spinner.setAdapter(adapterCourse);
        RadioButton radioButton;
        Button search = (Button) view.findViewById(R.id.searchbutton);
        EditText byIdentity = (EditText) view.findViewById(R.id.ID);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                //this is used for hiding radio buttons
                switch (i){
                    case R.id.byId: byIdentity.setVisibility(View.VISIBLE);
                                    course_spinner.setVisibility(View.GONE);

                                    flag = true;

                                    break;
                    case R.id.byPc: byIdentity.setVisibility(View.GONE);
                                    course_spinner.setVisibility(View.VISIBLE);

                                    flag = false;
                                    break;
                }
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(flag){
                    //selection of id
                    ID = byIdentity.getText().toString();
                    Cursor cursor = dataBaseHelper.viewDatabyId(ID);
                    if(cursor.getCount()==0){
                        showStatus("Error","No Data");
                        return;
                    }
                    //showing records from database
                    StringBuffer bfr;
                    bfr = showRecord(cursor);
                    showStatus("Current Record",bfr.toString());
                    cursor.close();
                }
                else{
                    //selection by program code
                  PC = course_spinner.getSelectedItem().toString();
                    Cursor cursor = dataBaseHelper.viewDatabyPC(PC);
                    if(cursor.getCount()==0){
                        showStatus("Error","No Data");
                        return;
                    }
                    StringBuffer bfr;
                    bfr = showRecord(cursor);
                    showStatus("Current Record",bfr.toString());
                    cursor.close();
                }
            }
        });

            dataBaseHelper.close();
            return view;

        }


public  void showStatus(String title, String resutContent){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(resutContent);
        builder.show();
        }
public  StringBuffer showRecord(Cursor cr){
        StringBuffer bfr = new StringBuffer();
        cr.moveToFirst();
         do{

        bfr.append("Data" + "\n");
        bfr.append("Program Id:" + cr.getInt(0) + "\n");
        bfr.append("First Name:" + cr.getString(1) + "\n");
        bfr.append("Last Name:" + cr.getString(2) + "\n");
        bfr.append("Marks:" + cr.getString(3) + "\n");
        bfr.append("Credit:" + cr.getString(4) + "\n");
        bfr.append("Programme Code:" + cr.getString(5) + "\n");

        }while (cr.moveToNext());
        return bfr;
        }


}